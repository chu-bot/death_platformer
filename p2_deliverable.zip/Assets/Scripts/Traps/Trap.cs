using UnityEngine;

public class Trap : MonoBehaviour { }