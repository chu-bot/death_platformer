using UnityEngine;

public class GameOverEvent
{
    public GameOverEvent()
    {}

    public override string ToString()
    {
        return "Game Over!";
    }
}
