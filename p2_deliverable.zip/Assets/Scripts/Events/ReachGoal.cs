using UnityEngine;

public class ReachGoalEvent
{

    public ReachGoalEvent() { }
    public override string ToString()
    {
        return $"Player Won";
    }
}
